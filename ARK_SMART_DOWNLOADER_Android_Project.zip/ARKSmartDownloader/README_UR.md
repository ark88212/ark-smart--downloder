# ARK SMART DOWNLOADER — Android starter project

یہ Android Studio کے لیے ابتدائی قابلِ تعمیر پروجیکٹ ہے، مکمل تجارتی ایپ یا تیار APK نہیں۔

## اس ورژن میں کیا کام کرتا ہے؟
- کالا/نیلا Jetpack Compose انٹرفیس
- زبان منتخب کرنے کا ابتدائی مینو (English، اردو، हिन्दी، العربية، پنجابی، بنگالی، چینی، ہسپانوی، فرانسیسی، جرمن)
- Google Search کھولنا
- YouTube پر ویڈیو تلاش کرنا
- Google News کھولنا
- صارف کے فراہم کردہ براہِ راست HTTP/HTTPS فائل لنک کو Android DownloadManager کے ذریعے ڈاؤن لوڈ کرنا

## کیا ابھی شامل/مکمل نہیں؟
- Google اکاؤنٹ لاگ اِن اور کلاؤڈ Sync (اس کے لیے Firebase/Google OAuth کنفیگریشن اور آپ کے اپنے پروجیکٹ کی credentials درکار ہیں)
- تمام زبانوں کے مکمل ترجمے (فی الحال زبان منتخب کرنے کا ابتدائی UI ہے؛ بیشتر اسکرین ٹیکسٹ ابھی انگریزی ہے)
- YouTube یا دیگر پلیٹ فارمز کی ویڈیوز براہِ راست ڈاؤن لوڈ کرنا؛ صرف پلیٹ فارم کی اجازت اور متعلقہ API/شرائط کے مطابق ہی ممکن ہے
- نیوز فیڈ کی اپنی اندرونی لسٹ/سرور، آف لائن میڈیا لائبریری، iOS/Windows ورژن
- Play Store release signing، privacy policy، data safety declarations اور مکمل QA

## Android Studio میں چلانے کا طریقہ
1. Android Studio کا تازہ مستحکم ورژن انسٹال کریں۔
2. اس ZIP کو Extract کریں۔
3. Android Studio میں `ARKSmartDownloader` فولڈر کھولیں۔
4. Gradle sync مکمل ہونے دیں (انٹرنیٹ درکار ہوگا)۔
5. Android فون میں Developer options اور USB debugging آن کرکے فون connect کریں، یا Android Emulator بنائیں۔
6. Run دبائیں۔

## APK بنانا
Android Studio میں **Build > Build Bundle(s) / APK(s) > Build APK(s)** منتخب کریں۔ Debug APK عام طور پر `app/build/outputs/apk/debug/app-debug.apk` میں بنتی ہے۔

## اگلا محفوظ ترقیاتی مرحلہ
- آپ کے نام پر Firebase project بنانا اور Android app کا package `com.ark.smartdownloader` رجسٹر کرنا۔
- Google Sign-In کو Credential Manager/Firebase Auth کے ذریعے configure کرنا؛ client secret کو ایپ میں hardcode نہ کریں۔
- Firestore/Cloud Storage rules کو authenticated user تک محدود کرنا۔
- مکمل ترجمے Android string resources میں شامل کرنا۔
- قابلِ اعتماد نیوز APIs/RSS، source attribution اور caching شامل کرنا۔
- Privacy policy، Terms، copyright-compliant download policy اور Play Store listing تیار کرنا۔

## اہم
اس پروجیکٹ کو حقیقی صارفین کے لیے شائع کرنے سے پہلے developer سے build، device testing، security review اور Google Play policy review کروائیں۔
