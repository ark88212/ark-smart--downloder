package com.ark.smartdownloader

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.net.URLEncoder

private val Navy = Color(0xFF080D18)
private val Panel = Color(0xFF121D30)
private val Blue = Color(0xFF2878F0)
private val Cyan = Color(0xFF16BDEB)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ArkApp() }
    }
}

@Composable
fun ArkApp() {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var downloadUrl by remember { mutableStateOf("") }
    var language by remember { mutableStateOf("English") }
    var languageMenu by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ready to explore") }

    val isUrdu = language == "اردو"
    val title = if (isUrdu) "ARK SMART DOWNLOADER" else "ARK SMART DOWNLOADER"

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Blue, secondary = Cyan, background = Navy,
            surface = Panel, onPrimary = Color.White, onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(containerColor = Navy) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text(title, color = Color(0xFF4D91FF), fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                        Text(if (isUrdu) "ایک ایپ، بہت سی سہولتیں" else "ONE APP • MANY TOOLS",
                            color = Color.LightGray, fontSize = 11.sp, letterSpacing = 1.4.sp)
                    }
                    Box {
                        OutlinedButton(onClick = { languageMenu = true }) {
                            Icon(Icons.Default.Language, null, tint = Cyan)
                            Spacer(Modifier.width(5.dp))
                            Text(language, color = Color.White)
                        }
                        DropdownMenu(expanded = languageMenu, onDismissRequest = { languageMenu = false }) {
                            listOf("English", "اردو", "हिन्दी", "العربية", "ਪੰਜਾਬੀ", "বাংলা", "中文", "Español", "Français", "Deutsch").forEach {
                                DropdownMenuItem(text = { Text(it) }, onClick = { language = it; languageMenu = false })
                            }
                        }
                    }
                }

                Spacer(Modifier.height(24.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Downloading, null, tint = Cyan, modifier = Modifier.size(54.dp))
                        Text(if (isUrdu) "اسمارٹ ڈاؤنلوڈر" else "SMART DOWNLOADER",
                            color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text(if (isUrdu) "ویب پر تلاش کریں یا براہِ راست فائل ڈاؤن لوڈ کریں" else "Search the web or download a direct file link",
                            color = Color.LightGray, fontSize = 12.sp)
                    }
                }

                Spacer(Modifier.height(20.dp))
                SectionTitle(if (isUrdu) "گوگل سرچ" else "GOOGLE SEARCH")
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text(if (isUrdu) "کچھ تلاش کریں..." else "Search anything...") },
                    singleLine = true, shape = RoundedCornerShape(14.dp),
                    trailingIcon = {
                        IconButton(onClick = { if (query.isNotBlank()) openUrl(context, "https://www.google.com/search?q=" + enc(query)) }) {
                            Icon(Icons.Default.Search, "Search", tint = Cyan)
                        }
                    }
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FeatureButton("Google", Icons.Default.Search, Modifier.weight(1f)) {
                        openUrl(context, "https://www.google.com/search?q=" + enc(query.ifBlank { "Google" }))
                    }
                    FeatureButton("YouTube", Icons.Default.PlayCircle, Modifier.weight(1f)) {
                        openUrl(context, "https://www.youtube.com/results?search_query=" + enc(query.ifBlank { "Videos" }))
                    }
                    FeatureButton("News", Icons.Default.Newspaper, Modifier.weight(1f)) {
                        openUrl(context, "https://news.google.com/")
                    }
                }

                Spacer(Modifier.height(22.dp))
                SectionTitle(if (isUrdu) "براہِ راست ڈاؤن لوڈ" else "DIRECT FILE DOWNLOAD")
                Text(if (isUrdu) "صرف ایسی فائل کا لنک دیں جسے ڈاؤن لوڈ کرنے کی اجازت ہو۔" else "Paste a direct file URL that you own or are authorized to download.",
                    color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = downloadUrl, onValueChange = { downloadUrl = it },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    placeholder = { Text("https://example.com/file.pdf") },
                    shape = RoundedCornerShape(14.dp)
                )
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        val uri = runCatching { Uri.parse(downloadUrl.trim()) }.getOrNull()
                        if (uri == null || (uri.scheme != "https" && uri.scheme != "http") || uri.host.isNullOrBlank()) {
                            Toast.makeText(context, "Enter a valid http/https direct file URL", Toast.LENGTH_LONG).show()
                        } else {
                            runCatching {
                                val request = DownloadManager.Request(uri)
                                    .setTitle(uri.lastPathSegment ?: "ARK download")
                                    .setDescription("Downloaded with ARK SMART DOWNLOADER")
                                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, uri.lastPathSegment ?: "ark-download")
                                    .setAllowedOverMetered(true).setAllowedOverRoaming(false)
                                val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                                manager.enqueue(request)
                                status = "Download added to Android Downloads"
                                Toast.makeText(context, status, Toast.LENGTH_LONG).show()
                            }.onFailure {
                                Toast.makeText(context, "Could not start download: ${it.message}", Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Blue),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Download, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (isUrdu) "ڈاؤن لوڈ شروع کریں" else "START DOWNLOAD")
                }

                Spacer(Modifier.height(18.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text(if (isUrdu) "حالت" else "STATUS", color = Cyan, fontWeight = FontWeight.Bold)
                        Text(status, color = Color.White, fontSize = 13.sp)
                    }
                }

                Spacer(Modifier.height(22.dp))
                SectionTitle(if (isUrdu) "مزید سہولیات" else "MORE TOOLS")
                ToolRow("Browser", "Open websites", Icons.Default.Public) { openUrl(context, "https://www.google.com") }
                ToolRow("Google News", "Browse global headlines", Icons.Default.Newspaper) { openUrl(context, "https://news.google.com/") }
                ToolRow("Downloads", "View Android download history", Icons.Default.FolderOpen) {
                    openUrl(context, "content://downloads/all_downloads")
                }
                Spacer(Modifier.height(18.dp))
                Text("ARK • SMART • SIMPLE", color = Blue, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("Version 0.1.0 • Android starter build", color = Color.Gray, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold,
        letterSpacing = 1.5.sp, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp))
}

@Composable
private fun FeatureButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector,
                          modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = modifier, contentPadding = PaddingValues(8.dp)) {
        Icon(icon, null, tint = Cyan, modifier = Modifier.size(17.dp))
        Spacer(Modifier.width(4.dp))
        Text(label, fontSize = 11.sp, color = Color.White)
    }
}

@Composable
private fun ToolRow(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(
        onClick = onClick, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Cyan, modifier = Modifier.size(26.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Color.LightGray, fontSize = 11.sp)
            }
            Spacer(Modifier.weight(1f))
            Icon(Icons.Default.ChevronRight, null, tint = Blue)
        }
    }
}

private fun openUrl(context: Context, url: String) {
    runCatching {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }.onFailure {
        Toast.makeText(context, "No app available to open this link", Toast.LENGTH_LONG).show()
    }
}

private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")
